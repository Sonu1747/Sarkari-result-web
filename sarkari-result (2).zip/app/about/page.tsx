"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { motion } from "framer-motion"
import { ArrowLeft, Github, Linkedin, Mail, MapPin, Calendar, Code, Heart, Sun, Moon } from "lucide-react"
import { useTheme } from "next-themes"
import { useRouter } from "next/navigation"

export default function AboutPage() {
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const router = useRouter()

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  const isDark = theme === "dark"

  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  // Developer images for the card scroll
  const developerImages = ["https://www.americanbazaaronline.com/wp-content/uploads/2020/06/Sundar-Pichai.png"]

  const skills = [
    "React.js",
    "Next.js",
    "TypeScript",
    "JavaScript",
    "Node.js",
    "Python",
    "MongoDB",
    "PostgreSQL",
    "AWS",
    "Docker",
    "Git",
    "Figma",
  ]

  const projects = [
    {
      title: "Sarkari Result Portal",
      description: "A comprehensive government job portal with modern UI/UX",
      tech: ["Next.js", "TypeScript", "Framer Motion", "Tailwind CSS"],
    },
    {
      title: "E-Commerce Platform",
      description: "Full-stack e-commerce solution with payment integration",
      tech: ["React", "Node.js", "MongoDB", "Stripe"],
    },
    {
      title: "Task Management App",
      description: "Collaborative task management with real-time updates",
      tech: ["React", "Socket.io", "Express", "PostgreSQL"],
    },
  ]

  return (
    <div
      className={`min-h-screen relative overflow-hidden ${
        isDark
          ? "bg-gradient-to-br from-purple-900 via-purple-800 to-pink-900 text-white"
          : "bg-gradient-to-br from-purple-400 via-purple-300 to-pink-400 text-gray-800"
      } transition-colors duration-500`}
    >
      {/* Animated Background Circles */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{
              x: `${Math.random() * 100}%`,
              y: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
            }}
            transition={{
              duration: 20 + Math.random() * 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
              ease: "easeInOut",
              delay: i * 2,
            }}
            className={`absolute rounded-full blur-xl ${
              i % 3 === 0 ? "bg-purple-500/30" : i % 3 === 1 ? "bg-pink-500/20" : "bg-blue-500/20"
            }`}
            style={{
              width: 100 + Math.random() * 200,
              height: 100 + Math.random() * 200,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 100 }}
        className={`backdrop-blur-xl ${
          isDark ? "bg-gray-900/30" : "bg-white/30"
        } border-b border-white/20 sticky top-0 z-40`}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={() => router.push("/?skipSplash=true")}
              className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                isDark ? "bg-gray-800/70" : "bg-white/70"
              } backdrop-blur-md border border-white/20 transition-all duration-300`}
            >
              <ArrowLeft className="w-4 h-4" />
              Back to Home
            </motion.button>
            <h1 className="text-2xl font-bold">About Developer</h1>
            <motion.button
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
              onClick={toggleTheme}
              className={`p-3 rounded-full ${
                isDark ? "bg-gray-800/70" : "bg-white/70"
              } backdrop-blur-md border border-white/20 transition-all duration-300`}
            >
              {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </motion.button>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="text-center mb-12"
        >
          {/* Profile Image */}
          <div className="relative mb-8 flex justify-center">
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.5 }}
              className="relative"
            >
              <Image
                src="/images/sonu-pal-profile.jpg"
                alt="Sonu Pal"
                width={180}
                height={180}
                className="rounded-full border-4 border-white/30 shadow-xl object-cover"
              />
              <motion.div
                animate={{
                  rotate: 360,
                }}
                transition={{
                  duration: 20,
                  repeat: Number.POSITIVE_INFINITY,
                  ease: "linear",
                }}
                className="absolute -inset-3 rounded-full border-2 border-dashed border-purple-400/50 z-0"
              />
            </motion.div>
          </div>

          {/* Name and College */}
          <motion.h2
            initial={{ opacity: 0, scale: 0.8 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.3, duration: 0.5 }}
            className="text-4xl md:text-6xl font-bold mb-4 bg-gradient-to-r from-purple-400 to-pink-400 bg-clip-text text-transparent"
          >
            SONU PAL
          </motion.h2>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.5, duration: 0.5 }}
            className={`text-xl md:text-2xl ${isDark ? "text-white/80" : "text-gray-700"} mb-2`}
          >
            Chandigarh Engineering College
          </motion.p>

          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.7, duration: 0.5 }}
            className={`text-lg ${isDark ? "text-white/60" : "text-gray-600"} mb-8`}
          >
            Full Stack Developer & UI/UX Designer
          </motion.p>

          {/* Social Links */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.9, duration: 0.5 }}
            className="flex justify-center gap-4 mb-8"
          >
            {[
              { icon: Github, href: "#", label: "GitHub" },
              { icon: Linkedin, href: "https://www.linkedin.com/in/sonu-pal-a53a22194/", label: "LinkedIn" },
              { icon: Mail, href: "mailto:sonupal.5079078@gmail.com", label: "Email" },
            ].map((social, index) => (
              <motion.a
                key={index}
                href={social.href}
                whileHover={{ scale: 1.1, y: -2 }}
                whileTap={{ scale: 0.95 }}
                className={`p-3 rounded-full ${
                  isDark ? "bg-gray-800/70" : "bg-white/70"
                } backdrop-blur-md border border-white/20 transition-all duration-300 hover:shadow-lg`}
              >
                <social.icon className="w-5 h-5" />
              </motion.a>
            ))}
          </motion.div>
        </motion.div>

        {/* About Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.1, duration: 0.8 }}
          className={`backdrop-blur-xl ${
            isDark ? "bg-gray-900/50" : "bg-white/30"
          } rounded-xl p-8 mb-8 border border-white/20 shadow-xl`}
        >
          <h3 className="text-2xl font-bold mb-4 flex items-center gap-2">
            <Heart className="w-6 h-6 text-red-500" />
            About Me
          </h3>
          <p className={`text-lg leading-relaxed ${isDark ? "text-white/80" : "text-gray-700"}`}>
            I'm a passionate full-stack developer currently studying at Chandigarh Engineering College. I love creating
            beautiful, functional web applications that solve real-world problems. My journey in tech started with
            curiosity and has evolved into a deep passion for building innovative solutions that make a difference in
            people's lives.
          </p>
        </motion.div>

        {/* Skills Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.3, duration: 0.8 }}
          className={`backdrop-blur-xl ${
            isDark ? "bg-gray-900/50" : "bg-white/30"
          } rounded-xl p-8 mb-8 border border-white/20 shadow-xl`}
        >
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Code className="w-6 h-6 text-blue-500" />
            Skills & Technologies
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {skills.map((skill, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ delay: 1.5 + index * 0.1, duration: 0.3 }}
                whileHover={{ scale: 1.05, y: -2 }}
                className={`px-4 py-2 rounded-full text-center ${
                  isDark ? "bg-purple-600/30" : "bg-purple-500/20"
                } border border-purple-400/30 backdrop-blur-md`}
              >
                {skill}
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Projects Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.8 }}
          className={`backdrop-blur-xl ${
            isDark ? "bg-gray-900/50" : "bg-white/30"
          } rounded-xl p-8 mb-8 border border-white/20 shadow-xl`}
        >
          <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
            <Calendar className="w-6 h-6 text-green-500" />
            Featured Projects
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 1.7 + index * 0.2, duration: 0.5 }}
                whileHover={{ y: -5, scale: 1.02 }}
                className={`p-6 rounded-xl ${
                  isDark ? "bg-gray-800/50" : "bg-white/50"
                } border border-white/20 backdrop-blur-md`}
              >
                <h4 className="text-xl font-bold mb-2">{project.title}</h4>
                <p className={`${isDark ? "text-white/70" : "text-gray-600"} mb-4`}>{project.description}</p>
                <div className="flex flex-wrap gap-2">
                  {project.tech.map((tech, techIndex) => (
                    <span
                      key={techIndex}
                      className={`px-2 py-1 text-xs rounded-full ${
                        isDark ? "bg-purple-600/20" : "bg-purple-500/20"
                      } border border-purple-400/30`}
                    >
                      {tech}
                    </span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>

        {/* Contact Section */}
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.9, duration: 0.8 }}
          className={`backdrop-blur-xl ${
            isDark ? "bg-gray-900/50" : "bg-white/30"
          } rounded-xl p-8 border border-white/20 shadow-xl text-center`}
        >
          <h3 className="text-2xl font-bold mb-4 flex items-center justify-center gap-2">
            <MapPin className="w-6 h-6 text-orange-500" />
            Let's Connect
          </h3>
          <p className={`text-lg ${isDark ? "text-white/80" : "text-gray-700"} mb-6`}>
            I'm always open to discussing new opportunities and interesting projects.
          </p>
          <motion.a
            href="mailto:sonupal.5079078@gmail.com"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            className="inline-flex items-center gap-2 px-8 py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-full font-semibold shadow-lg hover:from-purple-700 hover:to-pink-600 transition-all duration-300"
          >
            <Mail className="w-5 h-5" />
            Get In Touch
          </motion.a>
        </motion.div>
      </main>
    </div>
  )
}
