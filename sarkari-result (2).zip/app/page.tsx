"use client"

import React from "react"

import { useState, useEffect } from "react"
import Image from "next/image"
import Link from "next/link"
import { motion, AnimatePresence } from "framer-motion"
import { Search, Bell, ChevronRight, ChevronDown, Info, Sun, Moon, Send } from "lucide-react"
import { useTheme } from "next-themes"
import emailjs from "@emailjs/browser"
import SplashScreen from "@/components/splash-screen"
import ScrollingBanner from "@/components/scrolling-banner"
import { useRouter } from "next/navigation"

// Category Card Component
const CategoryCard = ({
  title,
  color,
  links,
  index = 0,
}: {
  title: string
  color: string
  links: string[]
  index?: number
}) => {
  const [expanded, setExpanded] = useState(false)
  const { theme } = useTheme()
  const isDark = theme === "dark"

  // Array of different gradient colors for dark mode
  const darkModeColors = [
    "from-purple-700/90 to-indigo-900/90",
    "from-blue-700/90 to-cyan-900/90",
    "from-emerald-700/90 to-teal-900/90",
    "from-amber-700/90 to-yellow-900/90",
    "from-pink-700/90 to-rose-900/90",
    "from-violet-700/90 to-purple-900/90",
    "from-cyan-700/90 to-blue-900/90",
    "from-fuchsia-700/90 to-pink-900/90",
  ]

  // Select a color based on the index or use a random one
  const darkColor = darkModeColors[index % darkModeColors.length]

  return (
    <motion.div
      variants={{
        hidden: { opacity: 0, y: 20 },
        show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 100 } },
      }}
      whileHover={{
        scale: 1.02,
        transition: { duration: 0.2 },
      }}
      className={`backdrop-blur-xl bg-gradient-to-br ${
        isDark
          ? darkColor
          : color.replace("from-red-700/90", "from-purple-600/80").replace("to-red-900/90", "to-pink-600/80")
      } rounded-xl overflow-hidden shadow-lg border border-white/20 transition-all duration-300`}
    >
      <div className="p-4 border-b border-white/20">
        <h3
          className={`text-xl font-bold text-center ${isDark ? "text-white" : "text-white"} transition-all duration-300 ${
            isDark ? "text-shadow-glow" : ""
          }`}
        >
          {title}
        </h3>
      </div>
      <div className="p-4 max-h-[400px] overflow-y-auto custom-scrollbar">
        <ul className="space-y-2">
          {links.slice(0, expanded ? links.length : 8).map((link, index) => (
            <motion.li
              key={index}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: index * 0.05 }}
              className="flex items-start"
            >
              <span className="text-white mr-2 mt-1">•</span>
              <Link
                href="#"
                className="text-blue-200 hover:text-white transition-colors duration-300 hover:underline flex-1 shimmer-effect"
              >
                {link}
              </Link>
            </motion.li>
          ))}
        </ul>
        {links.length > 8 && (
          <motion.button
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
            onClick={() => setExpanded(!expanded)}
            className="mt-4 w-full px-4 py-2 bg-white/10 hover:bg-white/20 backdrop-blur-md rounded-lg text-white flex items-center justify-center gap-2 transition-all duration-300"
          >
            {expanded ? "View Less" : "View More"}
            <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${expanded ? "rotate-180" : ""}`} />
          </motion.button>
        )}
      </div>
    </motion.div>
  )
}

// Enhanced Animated Background Elements
const AnimatedGlassOrb = ({
  size,
  color,
  delay,
  duration,
  blur = "xl",
}: {
  size: number
  color: string
  delay: number
  duration: number
  blur?: string
}) => {
  return (
    <motion.div
      initial={{
        x: `${Math.random() * 100}%`,
        y: `${Math.random() * 100}%`,
        scale: 0,
        opacity: 0,
      }}
      animate={{
        x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`],
        y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`, `${Math.random() * 100}%`],
        scale: [0, 1, 0.8, 1, 0.6],
        opacity: [0, 0.7, 0.4, 0.8, 0.3],
        rotate: [0, 180, 360],
      }}
      transition={{
        duration,
        delay,
        repeat: Number.POSITIVE_INFINITY,
        repeatType: "loop",
        ease: "easeInOut",
      }}
      className={`absolute rounded-full ${color} blur-${blur} backdrop-blur-sm`}
      style={{
        width: size,
        height: size,
        background: `radial-gradient(circle, ${
          color.includes("purple")
            ? "rgba(147, 51, 234, 0.3)"
            : color.includes("pink")
              ? "rgba(236, 72, 153, 0.3)"
              : color.includes("blue")
                ? "rgba(59, 130, 246, 0.3)"
                : "rgba(168, 85, 247, 0.3)"
        } 0%, transparent 70%)`,
        boxShadow: `0 0 ${size / 4}px ${
          color.includes("purple")
            ? "rgba(147, 51, 234, 0.4)"
            : color.includes("pink")
              ? "rgba(236, 72, 153, 0.4)"
              : color.includes("blue")
                ? "rgba(59, 130, 246, 0.4)"
                : "rgba(168, 85, 247, 0.4)"
        }`,
      }}
    />
  )
}

// Floating Particles Component
const FloatingParticles = () => {
  return (
    <>
      {[...Array(15)].map((_, i) => (
        <motion.div
          key={i}
          initial={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: 0,
          }}
          animate={{
            x: Math.random() * window.innerWidth,
            y: Math.random() * window.innerHeight,
            opacity: [0, 1, 0],
          }}
          transition={{
            duration: 8 + Math.random() * 4,
            repeat: Number.POSITIVE_INFINITY,
            delay: Math.random() * 5,
            ease: "easeInOut",
          }}
          className="absolute w-1 h-1 bg-white/40 rounded-full backdrop-blur-sm"
          style={{
            boxShadow: "0 0 6px rgba(255, 255, 255, 0.6)",
          }}
        />
      ))}
    </>
  )
}

// Feedback Form Component
const FeedbackForm = () => {
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [message, setMessage] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitStatus, setSubmitStatus] = useState<"idle" | "success" | "error" | "setup-needed">("idle")
  const { theme } = useTheme()
  const isDark = theme === "dark"
  const formRef = React.useRef<HTMLFormElement>(null)

  // EmailJS Configuration - Your actual credentials
  const EMAILJS_CONFIG = {
    USER_ID: "8j5V2eO8iApF0ymBQ", // Your actual EmailJS User ID
    SERVICE_ID: "service_xtbnafj", // Your actual EmailJS Service ID
    TEMPLATE_ID: "template_lpg3gd6", // Your actual EmailJS Template ID
  }

  // Check if EmailJS is properly configured
  const isEmailJSConfigured = true // EmailJS is now properly configured

  // Initialize EmailJS once when component mounts
  useEffect(() => {
    if (isEmailJSConfigured) {
      emailjs.init(EMAILJS_CONFIG.USER_ID)
    }
  }, [isEmailJSConfigured])

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    if (!formRef.current) return

    // Check if EmailJS is configured
    if (!isEmailJSConfigured) {
      setSubmitStatus("setup-needed")
      return
    }

    setIsSubmitting(true)
    setSubmitStatus("idle")

    try {
      // Prepare template parameters
      const templateParams = {
        from_name: name,
        from_email: email,
        message: message,
        to_email: "sonupal.5079078@gmail.com",
        reply_to: email,
      }

      // Send the email using EmailJS
      const response = await emailjs.send(EMAILJS_CONFIG.SERVICE_ID, EMAILJS_CONFIG.TEMPLATE_ID, templateParams)

      console.log("Email sent successfully:", response)
      setSubmitStatus("success")
      setName("")
      setEmail("")
      setMessage("")
    } catch (error) {
      console.error("Error sending email:", error)
      setSubmitStatus("error")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.8, duration: 0.5 }}
      className={`backdrop-blur-xl ${
        isDark ? "bg-gray-900/50" : "bg-white/30"
      } rounded-xl p-6 border border-white/20 shadow-xl`}
    >
      <h3 className="text-2xl font-bold mb-4 text-center">Send Us Your Feedback</h3>

      {submitStatus === "success" && (
        <div className="mb-4 p-3 bg-green-500/20 border border-green-500/30 rounded-lg text-green-300 text-center">
          Thank you! Your feedback has been sent successfully to sonupal.5079078@gmail.com.
        </div>
      )}

      {submitStatus === "error" && (
        <div className="mb-4 p-3 bg-red-500/20 border border-red-500/30 rounded-lg text-red-300 text-center">
          Sorry, there was an error sending your feedback. Please try again or contact us directly.
        </div>
      )}

      {submitStatus === "setup-needed" && (
        <div className="mb-4 p-3 bg-yellow-500/20 border border-yellow-500/30 rounded-lg text-yellow-300 text-center">
          EmailJS is not configured yet. Please set up your EmailJS credentials to enable email functionality.
        </div>
      )}

      <form ref={formRef} onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="name" className="block mb-2 text-sm font-medium">
            Your Name
          </label>
          <input
            type="text"
            id="name"
            name="from_name"
            value={name}
            onChange={(e) => setName(e.target.value)}
            required
            className={`w-full px-4 py-2 rounded-lg ${
              isDark ? "bg-gray-800/70" : "bg-white/70"
            } backdrop-blur-md border border-white/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all duration-300`}
            placeholder=""
          />
        </div>
        <div>
          <label htmlFor="email" className="block mb-2 text-sm font-medium">
            Your Email
          </label>
          <input
            type="email"
            id="email"
            name="from_email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className={`w-full px-4 py-2 rounded-lg ${
              isDark ? "bg-gray-800/70" : "bg-white/70"
            } backdrop-blur-md border border-white/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all duration-300`}
            placeholder=""
          />
        </div>
        <div>
          <label htmlFor="message" className="block mb-2 text-sm font-medium">
            Your Message
          </label>
          <textarea
            id="message"
            name="message"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={4}
            required
            className={`w-full px-4 py-2 rounded-lg ${
              isDark ? "bg-gray-800/70" : "bg-white/70"
            } backdrop-blur-md border border-white/20 focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all duration-300`}
            placeholder="Your feedback or query..."
          ></textarea>
        </div>
        <motion.button
          whileHover={{ scale: isSubmitting ? 1 : 1.03 }}
          whileTap={{ scale: isSubmitting ? 1 : 0.97 }}
          type="submit"
          disabled={isSubmitting}
          className={`w-full px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-lg flex items-center justify-center gap-2 shadow-lg hover:from-purple-700 hover:to-pink-600 transition-all duration-300 ${
            isSubmitting ? "opacity-70 cursor-not-allowed" : ""
          }`}
        >
          <Send className="w-4 h-4" />
          {isSubmitting ? "Sending..." : "Submit Feedback"}
        </motion.button>
      </form>
    </motion.div>
  )
}

export default function SarkariResult() {
  const [showSplash, setShowSplash] = useState(true)
  const [scrolled, setScrolled] = useState(false)
  const { theme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const router = useRouter()
  const [showSearch, setShowSearch] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")

  // Track mouse movement for cursor light flare

  // Check for skipSplash parameter
  useEffect(() => {
    // Get the current URL search params
    const searchParams = new URLSearchParams(window.location.search)
    // If skipSplash is true, don't show the splash screen
    if (searchParams.get("skipSplash") === "true") {
      setShowSplash(false)
    }
  }, [])

  // After mounting, we can safely show the UI that depends on the theme
  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50)
    }
    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  const container = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.3,
      },
    },
  }

  const item = {
    hidden: { y: 20, opacity: 0 },
    show: { y: 0, opacity: 1, transition: { type: "spring", stiffness: 300 } },
  }

  // Handle theme toggle
  const toggleTheme = () => {
    setTheme(theme === "dark" ? "light" : "dark")
  }

  // Handle splash screen completion
  const handleSplashComplete = () => {
    setShowSplash(false)
  }

  const handleSearchToggle = () => {
    setShowSearch(!showSearch)
    if (showSearch) {
      setSearchQuery("")
    }
  }

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (searchQuery.trim()) {
      // Redirect to search results page with query
      router.push(`/search?q=${encodeURIComponent(searchQuery.trim())}`)
    }
  }

  const handleSearchKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      setShowSearch(false)
      setSearchQuery("")
    }
  }

  // Only render the UI after mounting to avoid hydration mismatch
  if (!mounted) return null

  const isDark = theme === "dark"

  return (
    <AnimatePresence mode="wait">
      {showSplash ? (
        <SplashScreen key="splash" onComplete={handleSplashComplete} />
      ) : (
        <motion.div
          key="main"
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, ease: "easeOut" }}
          className={`min-h-screen relative overflow-hidden ${
            isDark
              ? "bg-gradient-to-br from-purple-900 via-purple-800 to-pink-900 text-white"
              : "bg-gradient-to-br from-purple-400 via-purple-300 to-pink-400 text-gray-800"
          } transition-colors duration-500`}
        >
          {/* Scrolling Banner - Fixed at top */}
          <div className="fixed top-0 left-0 right-0 z-50">
            <ScrollingBanner />
          </div>

          {/* Enhanced Animated Background with Glassmorphism */}
          <div className="absolute inset-0 overflow-hidden -z-10">
            {/* Large Glassmorphism Orbs */}
            <AnimatedGlassOrb size={300} color="bg-purple-500/20" delay={0} duration={25} blur="2xl" />
            <AnimatedGlassOrb size={250} color="bg-pink-500/15" delay={3} duration={30} blur="2xl" />
            <AnimatedGlassOrb size={200} color="bg-blue-500/15" delay={6} duration={22} blur="xl" />
            <AnimatedGlassOrb size={350} color="bg-indigo-500/10" delay={9} duration={35} blur="3xl" />

            {/* Medium Glassmorphism Orbs */}
            <AnimatedGlassOrb size={180} color="bg-violet-500/20" delay={2} duration={28} blur="xl" />
            <AnimatedGlassOrb size={150} color="bg-fuchsia-500/25" delay={5} duration={20} blur="lg" />
            <AnimatedGlassOrb size={220} color="bg-purple-600/15" delay={8} duration={32} blur="xl" />
            <AnimatedGlassOrb size={160} color="bg-pink-600/20" delay={11} duration={26} blur="lg" />

            {/* Small Glassmorphism Orbs */}
            <AnimatedGlassOrb size={120} color="bg-cyan-500/20" delay={1} duration={18} blur="lg" />
            <AnimatedGlassOrb size={100} color="bg-rose-500/25" delay={4} duration={24} blur="md" />
            <AnimatedGlassOrb size={140} color="bg-emerald-500/15" delay={7} duration={21} blur="lg" />
            <AnimatedGlassOrb size={110} color="bg-amber-500/20" delay={10} duration={19} blur="md" />

            {/* Floating Particles */}
            <FloatingParticles />

            {/* Gradient Overlay for depth */}
            <div
              className={`absolute inset-0 ${isDark ? "bg-gradient-to-br from-purple-900/20 via-transparent to-pink-900/20" : "bg-gradient-to-br from-purple-400/10 via-transparent to-pink-400/10"}`}
            />
          </div>

          {/* Header - Adjusted for banner */}
          <motion.header
            initial={{ y: -100 }}
            animate={{ y: 0 }}
            transition={{ type: "spring", stiffness: 100 }}
            className={`sticky top-8 z-40 backdrop-blur-xl ${
              scrolled ? (isDark ? "bg-gray-900/30" : "bg-white/30") : "bg-transparent"
            } transition-all duration-300`}
            style={{ marginTop: "32px" }} // Account for banner height
          >
            <div className="container mx-auto px-4 py-4">
              <div className="flex flex-col md:flex-row items-center justify-between">
                <div className="flex items-center gap-4">
                  <motion.div whileHover={{ rotate: 10, scale: 1.05 }} transition={{ type: "spring", stiffness: 300 }}>
                    <Image
                      src="https://www.logopeople.in/wp-content/uploads/2013/01/government-of-india.jpg"
                      alt="Sarkari Result Logo"
                      width={100}
                      height={100}
                      className="rounded-full border-4 border-white/30"
                    />
                  </motion.div>
                  <div className="text-center md:text-left">
                    <motion.h1
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={{ opacity: 1, scale: 1 }}
                      transition={{ duration: 0.5 }}
                      className="text-4xl md:text-5xl font-bold tracking-wider"
                    >
                      SARKARI RESULT
                    </motion.h1>
                    <motion.p
                      initial={{ opacity: 0 }}
                      animate={{ opacity: 1 }}
                      transition={{ delay: 0.3 }}
                      className={`${isDark ? "text-white/80" : "text-gray-700"} text-sm md:text-base`}
                    >
                      WWW.SARKARIRESULT.COM
                    </motion.p>
                  </div>
                </div>
                <div className="flex items-center gap-4 mt-4 md:mt-0">
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    onClick={toggleTheme}
                    className={`p-3 rounded-full ${
                      isDark ? "bg-gray-800/70" : "bg-white/70"
                    } backdrop-blur-xl shadow-lg border border-white/20 transition-all duration-300`}
                  >
                    {isDark ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
                  </motion.button>
                  <motion.button
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className="px-6 py-2 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-full flex items-center gap-2 backdrop-blur-md shadow-lg hover:from-purple-700 hover:to-pink-600 transition-all duration-300"
                  >
                    <Bell className="w-4 h-4" />
                    Sarkari job alerts
                  </motion.button>
                </div>
              </div>
            </div>
          </motion.header>

          {/* Navigation - Adjusted for banner */}
          <nav
            className={`backdrop-blur-xl sticky z-30 border-y ${isDark ? "border-white/10" : "border-gray-300/30"}`}
            style={{ top: "140px" }} // Adjusted for banner + header
          >
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              transition={{ delay: 0.5 }}
              className="container mx-auto overflow-x-auto"
            >
              <ul className="flex whitespace-nowrap justify-center gap-2 py-2">
                {["Home", "Latest Jobs", "Results", "Admit Card", "Answer Key", "Syllabus", "Search", "Contact Us"].map(
                  (item, index) => {
                    // Generate a unique gradient for each nav item
                    const gradients = [
                      "from-purple-600/70 to-pink-500/70",
                      "from-blue-600/70 to-purple-500/70",
                      "from-pink-500/70 to-red-500/70",
                      "from-indigo-600/70 to-blue-500/70",
                      "from-green-500/70 to-teal-500/70",
                      "from-yellow-500/70 to-orange-500/70",
                      "from-red-500/70 to-pink-500/70",
                      "from-teal-500/70 to-green-500/70",
                    ]

                    return (
                      <motion.li
                        key={index}
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="transition-all duration-300"
                      >
                        <Link
                          href="#"
                          className={`px-4 py-2 rounded-xl block transition-all duration-300 ${
                            isDark ? "text-white" : "text-gray-800"
                          } hover:text-white hover:shadow-lg hover:backdrop-blur-xl hover:bg-gradient-to-r hover:${gradients[index]}`}
                        >
                          {item}
                        </Link>
                      </motion.li>
                    )
                  },
                )}
              </ul>
            </motion.div>
          </nav>

          {/* Main Content - Adjusted for banner */}
          <main className="container mx-auto px-4 py-8" style={{ paddingTop: "2rem" }}>
            {/* Title Section */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.7 }}
              className="text-center mb-8"
            >
              <h2 className="text-xl md:text-2xl font-bold mb-4">Your Dream Job Starts Here – Find, Apply, Succeed!</h2>
              <div
                className={`backdrop-blur-xl ${
                  isDark ? "bg-gray-900/30" : "bg-white/30"
                } rounded-xl p-4 inline-block border border-white/20`}
              >
                <h3 className="text-xl font-bold">Welcome to No. 1 Education Portal Sarkari Result 2025</h3>
              </div>
            </motion.div>

            {/* Links Section */}
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className={`backdrop-blur-xl ${
                isDark ? "bg-gray-900/30" : "bg-white/30"
              } rounded-xl p-6 mb-8 text-center border ${isDark ? "border-white/20" : "border-gray-300/30"} shadow-xl`}
            >
              <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                {[
                  "Sarkari Result Android Apps",
                  "Sarkari Result Youtube Channel",
                  "Sarkari Result Apple / IOS Apps",
                  "Follow Instagram",
                ].map((link, index) => (
                  <Link
                    key={index}
                    href="#"
                    className={`${
                      isDark ? "text-blue-300 hover:text-blue-100" : "text-purple-700 hover:text-purple-900"
                    } font-medium transition-all duration-300 hover:underline shimmer-effect`}
                  >
                    {link}
                  </Link>
                ))}
              </motion.div>

              <motion.div variants={item} className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {[
                  "UKPSC Pre Online Form 2025",
                  "Bank of Baroda Peon Online Form 2025",
                  "IDBI Bank JAM Online Form 2025",
                  "NTA ICAR AIIEA Online Form 2025",
                  "MPESB ADDET Online Form 2025",
                  "Sarkari Result Portal 2025",
                  "Rajasthan Police Constable Online Form 2025",
                  "Cotton Corp Various Post Online Form 2025",
                  "UPSSSC PET Online Form 2025",
                ].map((link, index) => (
                  <Link
                    key={index}
                    href="#"
                    className={`${
                      isDark ? "text-blue-300 hover:text-blue-100" : "text-purple-700 hover:text-purple-900"
                    } font-medium transition-all duration-300 hover:underline shimmer-effect`}
                  >
                    {link}
                  </Link>
                ))}
              </motion.div>
            </motion.div>

            {/* Alert Buttons */}
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="flex flex-wrap justify-center gap-4 mb-8"
            >
              <motion.button
                variants={item}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-blue-500 text-white rounded-full flex items-center gap-2 backdrop-blur-md shadow-lg hover:from-purple-700 hover:to-blue-600 transition-all duration-300"
              >
                <Bell className="w-4 h-4" />
                Sarkari job alerts
              </motion.button>
              <motion.button
                variants={item}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                className="px-6 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-full flex items-center gap-2 backdrop-blur-md shadow-lg hover:from-pink-600 hover:to-purple-700 transition-all duration-300"
              >
                <Bell className="w-4 h-4" />
                Indian government job
              </motion.button>
            </motion.div>

            {/* Job Cards */}
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-12"
            >
              {[
                { title: "UPSSSC PET 2025", color: "from-yellow-600/80 to-yellow-800/80" },
                { title: "RRB ALP 2025", color: "from-blue-600/80 to-blue-800/80" },
                { title: "UKPSC Pre 2025", color: "from-orange-500/80 to-orange-700/80" },
                { title: "Rajasthan Constable", color: "from-red-800/80 to-red-900/80" },
                { title: "UP ITI Admissions", color: "from-red-600/80 to-red-800/80" },
                { title: "IDBI Bank JAM", color: "from-green-600/80 to-green-800/80" },
                { title: "KGMU Nursing Officer", color: "from-pink-500/80 to-pink-700/80" },
                { title: "UGC NET June 2025", color: "from-blue-400/80 to-blue-600/80" },
              ].map((job, index) => (
                <motion.div
                  key={index}
                  variants={item}
                  whileHover={{ y: -10, scale: 1.03 }}
                  className={`backdrop-blur-xl bg-gradient-to-br ${job.color} rounded-xl overflow-hidden shadow-lg border border-white/20 group`}
                >
                  <Link href="#" className="block p-6 text-center">
                    <h3 className="text-xl font-bold text-white mb-2">{job.title}</h3>
                    <div className="flex items-center justify-center mt-2">
                      <span className="text-white font-medium">Apply Online</span>
                      <ChevronRight className="w-5 h-5 text-white transform group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </motion.div>

            {/* Detailed Categories Section */}
            <motion.div
              variants={container}
              initial="hidden"
              animate="show"
              className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-12"
            >
              {/* Results Column */}
              <CategoryCard
                title="Result"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "UPSC Exam Calendar 2025",
                  "CBSE Board Result 10th, 12th Result 2025",
                  "Andhra Univ PGCET PG LLB Result 2025",
                  "CBSE Board Result 10th Result 2025",
                  "CISF Constable 10th Result 2025",
                  "BSEH Nursing Result MPHW 12th Result 2025",
                  "CBSE HSC Result 12th Result 2025",
                  "CBSE Board Result 10th Result 2025",
                  "BSEB 10th Result Regular Test Result 2025",
                  "SSC Revised Exam Calendar 2025",
                  "CBSE Board Result 10th Result 2025",
                  "CISF Bhrti Police Constable 2025",
                  "BSEB Junior Instructor 2025 Result",
                  "CBSE Board 10th Result 2025",
                  "ICAI CA Result 2025 Various Post Result 2025",
                  "Rajasthan BSTC Junior Engineer Result 2025",
                  "BSEB Matric 10th Result 2025",
                  "UPSC Revised Calendar 2025 UPSC Result",
                  "Uttrakhand Instructor 2025 Post Result",
                ]}
                index={0}
              />

              {/* Admit Card Column */}
              <CategoryCard
                title="Admit Card"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "DBATU COC Admit Card May 2025",
                  "UP NET 2025 Admit Card",
                  "Rajasthan BSTC Admit Card 2025",
                  "CBSE Board 10th Admit Card 2025",
                  "UPSC EPFO Admit Card 2025 Pre Prelims Exam Admit Card",
                  "MPPSC State Service Admit Card",
                  "RPSC Police Relation Officer RRO Admit Card 2025",
                  "SGPGIMS UPPCL Admit Card 2025",
                  "SGPGI JRO NEET Admit Card 2025 Prelims Exam Admit Card",
                  "UPPCL AE Admit Card 2025",
                  "CISF Fire Constable Admit Card 2025",
                  "CISF ITBP Lucknow JEA Typist Test Admit Card 2025",
                  "IT JEA Advanced Admit Card 2025",
                  "UPPCL JE Admit Card 2025",
                  "NTA CUET UG 2025 Admit Card",
                  "UPPCL AE Admit Card 2025 Various Post Admit Card",
                  "UPPCL JE Admit Card Mains Exam 2025",
                  "Allahabad High Court Group 3 Admit Card 2025",
                  "UPPSC Scientific Officer 2025 Admit Card",
                ]}
                index={1}
              />

              {/* Latest Jobs Column */}
              <CategoryCard
                title="Latest Jobs"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "AIIMS Bhopal Walk-INB Junior Officer 2025",
                  "UPPCL Pre Recruitment 2025 Online Form 2025",
                  "UP Jal Nigam Various Post Online Form 2025",
                  "Calcutta High 2025 Online Form 2025",
                  "UPPCL AE 2025 Online Form 2025",
                  "UP Vidhan Sabha Post Online Form 2025",
                  "Indian Overseas Bank 2025 Online Form 2025",
                  "Haryana HSSC Assistant Loco Pilot 2025",
                  "UPPCL JE 2025 Online Form 2025",
                  "NTA CUET 2025 Online Form 2025",
                  "UPPCL Pre 2025 Online Form 2025",
                  "CISF ITBP Lucknow Various Post 2025",
                  "Bank of Baroda BOB Office Assistant Online Form 2025",
                  "Rajasthan Police Constable Online Form 2025",
                  "UPPCL JE 2025 Online Form 2025",
                  "CISF ITBP Lucknow Various Post 2025",
                  "Army TGC 142 Online Exam 2025",
                  "UPPCL Various Officer Online Form 2025",
                  "CISF Sergeant Recruiter Online Form 2025",
                ]}
                index={2}
              />

              {/* Answer Key Column */}
              <CategoryCard
                title="Answer Key"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "UPSSSC Assistant Professor Answer Key 2025",
                  "NTA NMMSS Result Answer Key 2025",
                  "MPESB Group 4 Various Post Answer Key 2025",
                  "UPSSSC Assistant Professor Answer Key 2025",
                ]}
                index={3}
              />

              {/* Syllabus Column */}
              <CategoryCard
                title="Syllabus"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "NTA JEE Main Syllabus 2025",
                  "UPSSSC Homeopathic Pharmacist Syllabus 2025",
                  "UPSSSC JE Civil PGDCA 2025 Syllabus",
                  "UPSSSC Assistant Professor Syllabus 2025",
                  "UPSSSC BCR Technician Syllabus 2025",
                ]}
                index={4}
              />

              {/* Admission Column */}
              <CategoryCard
                title="Admission"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "UP Polytechnic JEE Online Form 2025 Extension",
                  "IGNOU Admission 2025 Online Form 2025",
                  "NTA NMMSS Online Form 2025",
                  "IGNOU OPENMAT Admission 2025",
                  "NTA CUET MBBS PG 2025 Online Form 2025",
                  "MBBS NEET 2025 Online Form 2025",
                  "BSEB Admissions 2025 Online Form 2025",
                  "UP CNET 2025 Online Form 2025",
                  "IGNOU Admission 2025 Online Form 2025",
                  "UP CNET 2025 Online Form 2025 Extension",
                ]}
                index={5}
              />

              {/* Certificate Verification Column */}
              <CategoryCard
                title="Certificate Verification"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "NTA CUET Duplicate 2025",
                  "MPESB SET 2025 E Certificate",
                  "UPSSSC PET 2025 Certificate",
                  "Voter ID Online Form 2024 E KYC",
                  "Aadhar Pan Card Link 2025",
                ]}
                index={6}
              />

              {/* Important Column */}
              <CategoryCard
                title="Important"
                color={isDark ? "from-red-700/90 to-red-900/90" : "from-purple-600/80 to-pink-600/80"}
                links={[
                  "MP Rojgar Panjikaran 2025",
                  "UP Scholarship Online Form 2024",
                  "SSC CPO Online Form 2024",
                  "UPSSSC PET Online Form Registration 2024",
                  "UPSC CSE Online Registration 2025",
                ]}
                index={7}
              />
            </motion.div>

            {/* Feedback Form */}
            <div className="mb-12">
              <h2 className={`text-2xl font-bold text-center mb-6 ${isDark ? "text-white" : "text-gray-800"}`}>
                We Value Your Feedback
              </h2>
              <FeedbackForm />
            </div>
          </main>

          {/* Footer */}
          <motion.footer
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 1.5 }}
            className={`mt-12 backdrop-blur-xl ${
              isDark ? "bg-gray-900/40" : "bg-white/40"
            } border-t ${isDark ? "border-white/10" : "border-gray-300/30"} py-6`}
          >
            <div className="container mx-auto px-4 text-center">
              <p className={isDark ? "text-white/70" : "text-gray-700"}>
                © 2025 SarkariResult.Com - All Rights Reserved
              </p>
            </div>
          </motion.footer>

          {/* Enhanced Search Component */}
          <div className="fixed bottom-6 right-6 flex flex-col gap-4 z-50">
            <motion.button
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 2, type: "spring" }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={() => router.push("/about")}
              className={`w-14 h-14 rounded-full ${
                isDark ? "bg-gray-800/70" : "bg-white/70"
              } backdrop-blur-xl flex items-center justify-center shadow-lg border ${
                isDark ? "border-white/30" : "border-gray-300/50"
              } cursor-pointer`}
            >
              <Info className={`w-6 h-6 ${isDark ? "text-white" : "text-gray-800"}`} />
            </motion.button>

            {/* Search Button */}
            <motion.button
              initial={{ opacity: 0, scale: 0 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ delay: 2.2, type: "spring" }}
              whileHover={{ scale: 1.1 }}
              whileTap={{ scale: 0.9 }}
              onClick={handleSearchToggle}
              className={`w-14 h-14 rounded-full ${
                isDark ? "bg-gray-800/70" : "bg-white/70"
              } backdrop-blur-xl flex items-center justify-center shadow-lg border ${
                isDark ? "border-white/30" : "border-gray-300/50"
              } transition-all duration-300 ${showSearch ? "bg-purple-600/70 border-purple-400/50" : ""}`}
            >
              <Search
                className={`w-6 h-6 ${showSearch ? "text-white" : isDark ? "text-white" : "text-gray-800"} transition-colors duration-300`}
              />
            </motion.button>
          </div>

          {/* Search Input Overlay */}
          <AnimatePresence>
            {showSearch && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                transition={{ duration: 0.3 }}
                className="fixed inset-0 bg-black/50 backdrop-blur-sm z-40 flex items-center justify-center p-4"
                onClick={(e) => {
                  if (e.target === e.currentTarget) {
                    setShowSearch(false)
                    setSearchQuery("")
                  }
                }}
              >
                <motion.div
                  initial={{ scale: 0.8, opacity: 0, y: 50 }}
                  animate={{ scale: 1, opacity: 1, y: 0 }}
                  exit={{ scale: 0.8, opacity: 0, y: 50 }}
                  transition={{ type: "spring", stiffness: 300, damping: 30 }}
                  className={`w-full max-w-2xl mx-auto backdrop-blur-xl ${
                    isDark ? "bg-gray-900/80" : "bg-white/80"
                  } rounded-3xl p-8 border ${isDark ? "border-white/20" : "border-gray-300/30"} shadow-2xl`}
                >
                  <div className="text-center mb-6">
                    <h3 className={`text-2xl font-bold ${isDark ? "text-white" : "text-gray-800"} mb-2`}>
                      Search Sarkari Results
                    </h3>
                    <p className={`${isDark ? "text-white/70" : "text-gray-600"} text-sm`}>
                      Find jobs, results, admit cards, and more...
                    </p>
                  </div>

                  <form onSubmit={handleSearchSubmit} className="relative">
                    <div className="relative">
                      <input
                        type="text"
                        value={searchQuery}
                        onChange={(e) => setSearchQuery(e.target.value)}
                        onKeyDown={handleSearchKeyDown}
                        placeholder="Type your search query here..."
                        autoFocus
                        className={`w-full px-6 py-4 pr-16 rounded-2xl ${
                          isDark
                            ? "bg-gray-800/70 text-white placeholder-gray-400"
                            : "bg-white/70 text-gray-800 placeholder-gray-500"
                        } backdrop-blur-md border ${isDark ? "border-white/20" : "border-gray-300/30"} focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition-all duration-300 text-lg`}
                      />
                      <motion.button
                        type="submit"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.95 }}
                        className="absolute right-2 top-1/2 transform -translate-y-1/2 w-12 h-12 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-xl flex items-center justify-center shadow-lg hover:from-purple-700 hover:to-pink-600 transition-all duration-300"
                      >
                        <Search className="w-5 h-5" />
                      </motion.button>
                    </div>
                  </form>

                  {/* Quick Search Suggestions */}
                  <div className="mt-6">
                    <p className={`text-sm font-medium ${isDark ? "text-white/80" : "text-gray-700"} mb-3`}>
                      Popular Searches:
                    </p>
                    <div className="flex flex-wrap gap-2">
                      {[
                        "UPSC Results",
                        "SSC Jobs",
                        "Railway Jobs",
                        "Bank Jobs",
                        "Police Recruitment",
                        "Teaching Jobs",
                        "NEET Results",
                        "JEE Results",
                      ].map((suggestion, index) => (
                        <motion.button
                          key={index}
                          whileHover={{ scale: 1.05 }}
                          whileTap={{ scale: 0.95 }}
                          onClick={() => {
                            setSearchQuery(suggestion)
                            router.push(`/search?q=${encodeURIComponent(suggestion)}`)
                          }}
                          className={`px-4 py-2 rounded-full text-sm ${
                            isDark
                              ? "bg-purple-600/30 text-purple-200 hover:bg-purple-600/50"
                              : "bg-purple-500/20 text-purple-700 hover:bg-purple-500/30"
                          } border ${isDark ? "border-purple-400/30" : "border-purple-400/40"} backdrop-blur-md transition-all duration-300`}
                        >
                          {suggestion}
                        </motion.button>
                      ))}
                    </div>
                  </div>

                  {/* Close Instructions */}
                  <div className="mt-6 text-center">
                    <p className={`text-xs ${isDark ? "text-white/50" : "text-gray-500"}`}>
                      Press{" "}
                      <kbd
                        className={`px-2 py-1 rounded ${isDark ? "bg-gray-700 text-white" : "bg-gray-200 text-gray-800"} text-xs`}
                      >
                        Esc
                      </kbd>{" "}
                      to close or click outside
                    </p>
                  </div>
                </motion.div>
              </motion.div>
            )}
          </AnimatePresence>

          <style jsx global>{`
            @keyframes float {
              0% {
                transform: translateY(0) translateX(0);
              }
              50% {
                transform: translateY(-20px) translateX(10px);
              }
              100% {
                transform: translateY(0) translateX(0);
              }
            }

            @keyframes pulse-glow {
              0%, 100% {
                opacity: 0.5;
                transform: scale(1);
              }
              50% {
                opacity: 0.8;
                transform: scale(1.05);
              }
            }

            .glass-morphism {
              backdrop-filter: blur(16px) saturate(180%);
              background-color: rgba(255, 255, 255, 0.1);
              border: 1px solid rgba(255, 255, 255, 0.2);
            }
          `}</style>
        </motion.div>
      )}
    </AnimatePresence>
  )
}
