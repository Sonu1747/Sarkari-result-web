"use client"

import { motion } from "framer-motion"

export default function ScrollingBanner() {
  const text =
    "This website is currently undergoing development, with ongoing enhancements aimed at improving functionality and user experience. Please check back later for the finalized version! • "

  return (
    <div className="relative w-full h-8 bg-gradient-to-r from-red-600 to-orange-500 overflow-hidden z-50">
      <motion.div
        animate={{
          x: ["100%", "-100%"],
        }}
        transition={{
          duration: 15,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
        className="absolute top-0 left-0 h-full flex items-center whitespace-nowrap"
      >
        <span className="text-white font-semibold text-sm tracking-wide px-4">{text}</span>
      </motion.div>

      {/* Duplicate text for seamless loop */}
      <motion.div
        animate={{
          x: ["200%", "0%"],
        }}
        transition={{
          duration: 15,
          repeat: Number.POSITIVE_INFINITY,
          ease: "linear",
        }}
        className="absolute top-0 left-0 h-full flex items-center whitespace-nowrap"
      >
        <span className="text-white font-semibold text-sm tracking-wide px-4">{text}</span>
      </motion.div>
    </div>
  )
}
