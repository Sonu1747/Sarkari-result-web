"use client"

import { useState, useEffect, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion } from "framer-motion"
import { Search, ArrowLeft, Filter, Calendar, MapPin, Briefcase, FileText, Award, GraduationCap } from "lucide-react"
import { useTheme } from "next-themes"
import Link from "next/link"

// Search Results Component
function SearchResults() {
  const searchParams = useSearchParams()
  const router = useRouter()
  const { theme } = useTheme()
  const [mounted, setMounted] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [filteredResults, setFilteredResults] = useState<any[]>([])
  const [selectedCategory, setSelectedCategory] = useState("all")

  useEffect(() => {
    setMounted(true)
    const query = searchParams.get("q") || ""
    setSearchQuery(query)
  }, [searchParams])

  // Mock search results data
  const mockResults = [
    {
      id: 1,
      title: "UPSC Civil Services Examination 2025",
      category: "results",
      description: "Union Public Service Commission Civil Services Preliminary Examination Results",
      date: "2025-01-15",
      location: "All India",
      type: "Result",
      icon: Award,
      link: "#",
    },
    {
      id: 2,
      title: "SSC CGL 2025 Recruitment",
      category: "jobs",
      description: "Staff Selection Commission Combined Graduate Level Examination",
      date: "2025-02-01",
      location: "All India",
      type: "Job",
      icon: Briefcase,
      link: "#",
    },
    {
      id: 3,
      title: "Railway RRB NTPC Admit Card 2025",
      category: "admit-cards",
      description: "Railway Recruitment Board Non-Technical Popular Categories",
      date: "2025-01-20",
      location: "All India",
      type: "Admit Card",
      icon: FileText,
      link: "#",
    },
    {
      id: 4,
      title: "Bank PO Recruitment 2025",
      category: "jobs",
      description: "Various Banks Probationary Officer Recruitment",
      date: "2025-01-25",
      location: "All India",
      type: "Job",
      icon: Briefcase,
      link: "#",
    },
    {
      id: 5,
      title: "NEET UG Results 2025",
      category: "results",
      description: "National Eligibility cum Entrance Test for Undergraduate",
      date: "2025-01-30",
      location: "All India",
      type: "Result",
      icon: GraduationCap,
      link: "#",
    },
    {
      id: 6,
      title: "Police Constable Recruitment 2025",
      category: "jobs",
      description: "State Police Constable Recruitment Various States",
      date: "2025-02-05",
      location: "Multiple States",
      type: "Job",
      icon: Briefcase,
      link: "#",
    },
  ]

  // Filter results based on search query and category
  useEffect(() => {
    let results = mockResults

    // Filter by search query
    if (searchQuery) {
      results = results.filter(
        (item) =>
          item.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
          item.description.toLowerCase().includes(searchQuery.toLowerCase()),
      )
    }

    // Filter by category
    if (selectedCategory !== "all") {
      results = results.filter((item) => item.category === selectedCategory)
    }

    setFilteredResults(results)
  }, [searchQuery, selectedCategory])

  if (!mounted) return null

  const isDark = theme === "dark"

  const categories = [
    { id: "all", name: "All Results", count: filteredResults.length },
    { id: "jobs", name: "Jobs", count: mockResults.filter((r) => r.category === "jobs").length },
    { id: "results", name: "Results", count: mockResults.filter((r) => r.category === "results").length },
    { id: "admit-cards", name: "Admit Cards", count: mockResults.filter((r) => r.category === "admit-cards").length },
  ]

  return (
    <div
      className={`min-h-screen relative overflow-hidden ${
        isDark
          ? "bg-gradient-to-br from-purple-900 via-purple-800 to-pink-900 text-white"
          : "bg-gradient-to-br from-purple-400 via-purple-300 to-pink-400 text-gray-800"
      } transition-colors duration-500`}
    >
      {/* Animated Background */}
      <div className="absolute inset-0 overflow-hidden -z-10">
        {[...Array(6)].map((_, i) => (
          <motion.div
            key={i}
            initial={{
              x: `${Math.random() * 100}%`,
              y: `${Math.random() * 100}%`,
            }}
            animate={{
              x: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
              y: [`${Math.random() * 100}%`, `${Math.random() * 100}%`],
            }}
            transition={{
              duration: 20 + Math.random() * 10,
              repeat: Number.POSITIVE_INFINITY,
              repeatType: "reverse",
              ease: "easeInOut",
              delay: i * 2,
            }}
            className={`absolute rounded-full blur-xl ${
              i % 3 === 0 ? "bg-purple-500/30" : i % 3 === 1 ? "bg-pink-500/20" : "bg-blue-500/20"
            }`}
            style={{
              width: 100 + Math.random() * 200,
              height: 100 + Math.random() * 200,
            }}
          />
        ))}
      </div>

      {/* Header */}
      <motion.header
        initial={{ y: -100 }}
        animate={{ y: 0 }}
        transition={{ type: "spring", stiffness: 100 }}
        className={`backdrop-blur-xl ${
          isDark ? "bg-gray-900/30" : "bg-white/30"
        } border-b border-white/20 sticky top-0 z-40`}
      >
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => router.push("/")}
                className={`flex items-center gap-2 px-4 py-2 rounded-full ${
                  isDark ? "bg-gray-800/70" : "bg-white/70"
                } backdrop-blur-md border border-white/20 transition-all duration-300`}
              >
                <ArrowLeft className="w-4 h-4" />
                Back to Home
              </motion.button>
              <div>
                <h1 className="text-xl font-bold">Search Results</h1>
                {searchQuery && (
                  <p className={`text-sm ${isDark ? "text-white/70" : "text-gray-600"}`}>Results for "{searchQuery}"</p>
                )}
              </div>
            </div>
            <div className="flex items-center gap-2">
              <Search className="w-5 h-5" />
              <span className="text-sm font-medium">{filteredResults.length} results found</span>
            </div>
          </div>
        </div>
      </motion.header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Category Filters */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="mb-8"
        >
          <div className="flex items-center gap-4 mb-4">
            <Filter className="w-5 h-5" />
            <h2 className="text-lg font-semibold">Filter by Category</h2>
          </div>
          <div className="flex flex-wrap gap-3">
            {categories.map((category) => (
              <motion.button
                key={category.id}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => setSelectedCategory(category.id)}
                className={`px-4 py-2 rounded-full flex items-center gap-2 transition-all duration-300 ${
                  selectedCategory === category.id
                    ? "bg-gradient-to-r from-purple-600 to-pink-500 text-white shadow-lg"
                    : isDark
                      ? "bg-gray-800/70 text-white hover:bg-gray-700/70"
                      : "bg-white/70 text-gray-800 hover:bg-white/90"
                } backdrop-blur-md border border-white/20`}
              >
                <span>{category.name}</span>
                <span
                  className={`text-xs px-2 py-1 rounded-full ${
                    selectedCategory === category.id ? "bg-white/20" : isDark ? "bg-purple-600/30" : "bg-purple-500/20"
                  }`}
                >
                  {category.count}
                </span>
              </motion.button>
            ))}
          </div>
        </motion.div>

        {/* Search Results */}
        <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.4 }} className="space-y-6">
          {filteredResults.length > 0 ? (
            filteredResults.map((result, index) => (
              <motion.div
                key={result.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 * index }}
                whileHover={{ y: -5, scale: 1.02 }}
                className={`backdrop-blur-xl ${
                  isDark ? "bg-gray-900/50" : "bg-white/30"
                } rounded-xl p-6 border border-white/20 shadow-xl transition-all duration-300`}
              >
                <Link href={result.link} className="block">
                  <div className="flex items-start gap-4">
                    <div
                      className={`p-3 rounded-full ${
                        isDark ? "bg-purple-600/30" : "bg-purple-500/20"
                      } border border-purple-400/30`}
                    >
                      <result.icon className="w-6 h-6 text-purple-400" />
                    </div>
                    <div className="flex-1">
                      <h3 className="text-xl font-bold mb-2 hover:text-purple-400 transition-colors">{result.title}</h3>
                      <p className={`${isDark ? "text-white/70" : "text-gray-600"} mb-4`}>{result.description}</p>
                      <div className="flex flex-wrap items-center gap-4 text-sm">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          <span>{new Date(result.date).toLocaleDateString()}</span>
                        </div>
                        <div className="flex items-center gap-1">
                          <MapPin className="w-4 h-4" />
                          <span>{result.location}</span>
                        </div>
                        <span
                          className={`px-3 py-1 rounded-full text-xs ${
                            result.type === "Job"
                              ? "bg-green-500/20 text-green-400 border border-green-400/30"
                              : result.type === "Result"
                                ? "bg-blue-500/20 text-blue-400 border border-blue-400/30"
                                : "bg-orange-500/20 text-orange-400 border border-orange-400/30"
                          }`}
                        >
                          {result.type}
                        </span>
                      </div>
                    </div>
                  </div>
                </Link>
              </motion.div>
            ))
          ) : (
            <motion.div
              initial={{ opacity: 0, scale: 0.8 }}
              animate={{ opacity: 1, scale: 1 }}
              className={`text-center py-16 backdrop-blur-xl ${
                isDark ? "bg-gray-900/50" : "bg-white/30"
              } rounded-xl border border-white/20`}
            >
              <Search className="w-16 h-16 mx-auto mb-4 opacity-50" />
              <h3 className="text-2xl font-bold mb-2">No Results Found</h3>
              <p className={`${isDark ? "text-white/70" : "text-gray-600"} mb-6`}>
                Try adjusting your search terms or browse our categories
              </p>
              <motion.button
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => router.push("/")}
                className="px-6 py-3 bg-gradient-to-r from-purple-600 to-pink-500 text-white rounded-full font-semibold shadow-lg hover:from-purple-700 hover:to-pink-600 transition-all duration-300"
              >
                Back to Home
              </motion.button>
            </motion.div>
          )}
        </motion.div>
      </main>
    </div>
  )
}

// Main component with Suspense wrapper
export default function SearchPage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-purple-900 via-purple-800 to-pink-900">
          <div className="text-white text-xl">Loading search results...</div>
        </div>
      }
    >
      <SearchResults />
    </Suspense>
  )
}
